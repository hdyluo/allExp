//
//  LineView.h
//  SHRegister
//
//  Created by huangdeyu on 16/3/9.
//  Copyright © 2016年 huang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LineView : UIView
@property(nonatomic,strong)CAShapeLayer * sharpLayer;
@end
